import React, { useState } from 'react';
import { AppTheme, NoteRequest } from './types';
import { generateStudyNotes, generateVisuals } from './services/geminiService';
import { ThemeToggle } from './components/ThemeToggle';
import { ChatInterface } from './components/ChatInterface';
import jsPDF from 'jspdf';
import { Document, Packer, Paragraph, TextRun, Footer, Header, AlignmentType, ImageRun } from 'docx';
import saveAs from 'file-saver';

const App: React.FC = () => {
  // --- State ---
  const [theme, setTheme] = useState<AppTheme>(AppTheme.LIGHT);
  const [loading, setLoading] = useState(false);
  const [notes, setNotes] = useState<string | null>(null);
  const [visualUrls, setVisualUrls] = useState<string[]>([]);
  
  // Form Inputs
  const [subject, setSubject] = useState('');
  const [topic, setTopic] = useState('');
  const [marks, setMarks] = useState('10'); // Default to 10 marks
  const [contextText, setContextText] = useState('');
  const [contextLink, setContextLink] = useState('');
  const [file, setFile] = useState<File | null>(null);

  // Common Subjects for Suggestions
  const commonSubjects = [
    "Mathematics", "Physics", "Chemistry", "Biology", 
    "History", "Geography", "English Literature", 
    "Computer Science", "Economics", "Psychology", 
    "Business Studies", "Political Science"
  ];

  // --- Handlers ---

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => {
        const result = reader.result as string;
        const base64Content = result.split(',')[1];
        resolve(base64Content);
      };
      reader.onerror = error => reject(error);
    });
  };

  const handleGenerate = async () => {
    if (!subject || !topic) {
      alert("Please enter both Subject and Topic.");
      return;
    }

    setLoading(true);
    setNotes(null);
    setVisualUrls([]);

    try {
      let fileData;
      if (file) {
        const b64 = await fileToBase64(file);
        fileData = {
          data: b64,
          mimeType: file.type
        };
      }

      const request: NoteRequest = {
        subject,
        topic,
        marks,
        contextText,
        contextLink,
        fileData
      };

      const [generatedNotes, generatedImages] = await Promise.all([
        generateStudyNotes(request),
        generateVisuals(subject, topic)
      ]);

      setNotes(generatedNotes);
      setVisualUrls(generatedImages);

    } catch (error) {
      console.error("Failed to generate content:", error);
      alert("Something went wrong while generating notes. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  // --- Download Logic Helpers ---

  const formatHtmlForDownload = (html: string) => {
    let text = html;
    text = text.replace(/<br\s*\/?>/gi, '\n');
    text = text.replace(/<\/p>/gi, '\n\n');
    text = text.replace(/<\/h3>/gi, '\n\n'); 
    text = text.replace(/<h3>/gi, '\n\n[ '); 
    text = text.replace(/<\/h3>/gi, ' ]\n'); 
    text = text.replace(/<h3>/gi, '\n');
    text = text.replace(/<li>/gi, '• ');
    text = text.replace(/<\/li>/gi, '\n');
    text = text.replace(/<\/ul>/gi, '\n');
    text = text.replace(/<[^>]+>/g, '');
    text = text.replace(/\n\s*\n\s*\n/g, '\n\n');
    text = text.replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>');
    return text.trim();
  };

  const downloadPDF = () => {
    if (!notes) return;
    const doc = new jsPDF();
    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();
    const margin = 20;
    let cursorY = 20;

    // Header
    const addHeader = () => {
        doc.setFontSize(14);
        doc.setTextColor(50);
        doc.setFont("helvetica", "bold");
        doc.text("AI Study Notes Generator", pageWidth / 2, 10, { align: 'center' });
        doc.setFontSize(10);
        doc.setFont("helvetica", "normal");
        doc.text("Made by Loveleena 💖", pageWidth / 2, 16, { align: 'center' });
    };
    
    addHeader();
    
    // Title
    cursorY = 30;
    doc.setFontSize(18);
    doc.setTextColor(0);
    doc.setFont("helvetica", "bold");
    doc.text(`${subject.toUpperCase()}: ${topic.toUpperCase()}`, margin, cursorY);
    cursorY += 10;
    doc.setFontSize(12);
    doc.setTextColor(100);
    doc.text(`(Target: ${marks} Marks)`, margin, cursorY);
    cursorY += 15;

    // Content
    doc.setFontSize(11);
    doc.setTextColor(0);
    doc.setFont("helvetica", "normal");
    
    const plainTextNotes = formatHtmlForDownload(notes);
    const splitNotes = doc.splitTextToSize(plainTextNotes, pageWidth - (margin * 2));
    
    for (let i = 0; i < splitNotes.length; i++) {
        if (cursorY > pageHeight - 25) {
            doc.addPage();
            cursorY = 25;
            addHeader();
            doc.setFontSize(11);
            doc.setTextColor(0);
        }
        doc.text(splitNotes[i], margin, cursorY);
        cursorY += 6;
    }

    // Add Images
    if (visualUrls.length > 0) {
       for(let i = 0; i < visualUrls.length; i++) {
         if (cursorY > pageHeight - 110) {
            doc.addPage();
            cursorY = 25;
            addHeader();
         } else {
            cursorY += 10;
         }
         try {
           doc.addImage(visualUrls[i], 'PNG', margin, cursorY, 100, 100);
           doc.setFontSize(10);
           doc.setTextColor(100);
           doc.text(`Visual Aid ${i + 1}`, margin, cursorY + 105);
           cursorY += 115;
         } catch (e) {
           console.error("Could not add image to PDF", e);
         }
       }
    }

    // Footer loop
    const pageCount = doc.internal.pages.length - 1;
    for(let i = 1; i <= pageCount; i++) {
        doc.setPage(i);
        doc.setFontSize(9);
        doc.setTextColor(100);
        doc.text("Generated using AI Study Notes Generator | Made by Loveleena 💖", pageWidth / 2, pageHeight - 10, { align: 'center' });
    }

    doc.save(`${topic.replace(/\s+/g, '_')}_notes.pdf`);
  };

  const downloadWord = () => {
    if (!notes) return;

    const plainTextNotes = formatHtmlForDownload(notes);

    const paragraphs = plainTextNotes.split('\n').map(line => new Paragraph({
        children: [new TextRun({ text: line, font: "Calibri", size: 24 })],
        spacing: { after: 120 }
    }));
    
    // Create image paragraphs
    const imageParagraphs = visualUrls.map((url, idx) => {
        // Docx requires buffer or uint8array or base64 without prefix
        const base64Data = url.split(',')[1];
        return new Paragraph({
            children: [
                new TextRun({ text: `Visual Aid ${idx + 1}:`, bold: true, break: 1 }),
                new ImageRun({
                    data: Uint8Array.from(atob(base64Data), c => c.charCodeAt(0)),
                    transformation: { width: 400, height: 400 },
                    type: "png"
                })
            ],
            spacing: { before: 200, after: 200 }
        });
    });

    const doc = new Document({
      sections: [{
        headers: {
            default: new Header({
                children: [
                    new Paragraph({
                        children: [
                            new TextRun({ text: "AI Study Notes Generator", bold: true, size: 28 }),
                        ],
                        alignment: AlignmentType.CENTER
                    }),
                    new Paragraph({
                        children: [
                             new TextRun({ text: "Made by Loveleena 💖", size: 20 })
                        ],
                        alignment: AlignmentType.CENTER
                    })
                ]
            })
        },
        footers: {
            default: new Footer({
                children: [
                    new Paragraph({
                        children: [new TextRun({ text: "Generated using AI Study Notes Generator | Made by Loveleena 💖", color: "666666", size: 18 })],
                        alignment: AlignmentType.CENTER
                    })
                ]
            })
        },
        children: [
          new Paragraph({
            children: [
                new TextRun({ text: subject.toUpperCase() + ": " + topic.toUpperCase(), bold: true, size: 32 }),
                new TextRun({ text: `\n(Target: ${marks} Marks)`, size: 24, italics: true })
            ],
            spacing: { after: 300 }
          }),
          ...paragraphs,
          ...imageParagraphs,
          new Paragraph({
             children: [new TextRun({ text: "[Note: Full formatting best viewed in web app]", italics: true, size: 20 })],
             spacing: { before: 400 }
          })
        ]
      }]
    });

    Packer.toBlob(doc).then(blob => {
      saveAs(blob, `${topic.replace(/\s+/g, '_')}_notes.docx`);
    });
  };

  // --- Rendering Helpers ---

  const getThemeWrapperClass = () => {
    switch(theme) {
      case AppTheme.DARK: return 'bg-gray-900 text-gray-100';
      case AppTheme.FOCUS: return 'bg-focus-bg text-focus-text';
      default: return 'bg-slate-50 text-slate-900';
    }
  };

  const getInputClass = () => {
    switch(theme) {
        case AppTheme.DARK: return 'bg-gray-800 border-gray-700 text-white placeholder-gray-500 focus:ring-blue-500';
        case AppTheme.FOCUS: return 'bg-white border-focus-accent text-focus-text placeholder-gray-400 focus:ring-amber-500';
        default: return 'bg-white border-gray-300 text-gray-900 placeholder-gray-400 focus:ring-blue-500';
    }
  };

  const getCardClass = () => {
     switch(theme) {
        case AppTheme.DARK: return 'bg-gray-800 border-gray-700 shadow-xl';
        case AppTheme.FOCUS: return 'bg-white border-focus-accent shadow-sm';
        default: return 'bg-white border-gray-200 shadow-lg';
     }
  };

  return (
    <div className={`min-h-screen transition-colors duration-300 ${getThemeWrapperClass()}`}>
      
      {/* Navbar */}
      <nav className={`sticky top-0 z-40 px-6 py-4 flex justify-between items-center border-b backdrop-blur-md ${theme === AppTheme.DARK ? 'border-gray-800 bg-gray-900/80' : 'border-gray-200 bg-white/80'}`}>
        <div className="flex items-center gap-2">
          <span className="text-2xl">🎓</span>
          <div className="flex flex-col">
            <h1 className="font-bold text-xl tracking-tight leading-none">AI Study Notes</h1>
            <span className="text-xs opacity-60">Made by Loveleena 💖</span>
          </div>
        </div>
        <ThemeToggle currentTheme={theme} onThemeChange={setTheme} />
      </nav>

      <main className="max-w-4xl mx-auto p-6 pb-24">
        
        {/* Input Section */}
        <section className={`rounded-2xl p-6 mb-8 border ${getCardClass()}`}>
          <h2 className="text-xl font-bold mb-6 flex items-center gap-2">
            <span>📝</span> Setup Your Notes
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* Subject, Topic, Marks */}
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-1 opacity-80">Subject</label>
                <input
                  list="subjects"
                  type="text"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder="Select or Type (e.g. Biology)"
                  className={`w-full rounded-lg border px-4 py-2 outline-none focus:ring-2 transition-all ${getInputClass()}`}
                />
                <datalist id="subjects">
                  {commonSubjects.map(sub => <option key={sub} value={sub} />)}
                </datalist>
              </div>
              <div className="flex gap-4">
                  <div className="flex-1">
                    <label className="block text-sm font-medium mb-1 opacity-80">Topic</label>
                    <input
                    type="text"
                    value={topic}
                    onChange={(e) => setTopic(e.target.value)}
                    placeholder="e.g. Photosynthesis"
                    className={`w-full rounded-lg border px-4 py-2 outline-none focus:ring-2 transition-all ${getInputClass()}`}
                    />
                  </div>
                  <div className="w-1/3">
                    <label className="block text-sm font-medium mb-1 opacity-80">Marks</label>
                    <select
                        value={marks}
                        onChange={(e) => setMarks(e.target.value)}
                        className={`w-full rounded-lg border px-4 py-2 outline-none focus:ring-2 transition-all appearance-none ${getInputClass()}`}
                    >
                        <option value="2">2 Marks</option>
                        <option value="5">5 Marks</option>
                        <option value="10">10 Marks</option>
                        <option value="15">15 Marks</option>
                    </select>
                  </div>
              </div>
            </div>

            {/* Optional Materials */}
            <div className="space-y-4">
               <div>
                <label className="block text-sm font-medium mb-1 opacity-80">Add Learning Context (Optional)</label>
                <textarea
                  value={contextText}
                  onChange={(e) => setContextText(e.target.value)}
                  placeholder="Paste text, notes, or requirements here..."
                  className={`w-full h-24 rounded-lg border px-4 py-2 outline-none focus:ring-2 transition-all ${getInputClass()}`}
                />
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                    <label className="block text-sm font-medium mb-1 opacity-80">Link (Web/YT)</label>
                    <input
                    type="text"
                    value={contextLink}
                    onChange={(e) => setContextLink(e.target.value)}
                    placeholder="https://..."
                    className={`w-full rounded-lg border px-4 py-2 outline-none focus:ring-2 transition-all ${getInputClass()}`}
                    />
                </div>
                <div>
                    <label className="block text-sm font-medium mb-1 opacity-80">Upload File</label>
                    <input
                    type="file"
                    accept=".pdf,.txt"
                    onChange={handleFileChange}
                    className={`w-full text-sm file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100 ${theme === AppTheme.DARK ? 'text-gray-300' : 'text-gray-500'}`}
                    />
                </div>
              </div>
            </div>
          </div>

          <div className="mt-8 flex justify-end">
            <button
              onClick={handleGenerate}
              disabled={loading}
              className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-8 rounded-xl shadow-lg hover:shadow-blue-500/30 transform hover:-translate-y-1 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
            >
              {loading ? (
                <>
                   <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Generating...
                </>
              ) : (
                <>Create Notes ✨</>
              )}
            </button>
          </div>
        </section>

        {/* Output Section */}
        {notes && (
          <div className="space-y-8 animate-fade-in-up">
            
            {/* Action Bar */}
            <div className={`p-4 rounded-xl border flex flex-wrap gap-4 justify-between items-center ${theme === AppTheme.DARK ? 'bg-green-900/20 border-green-800' : 'bg-green-50 border-green-100'}`}>
               <div className={`font-medium flex items-center gap-2 ${theme === AppTheme.DARK ? 'text-green-400' : 'text-green-800'}`}>
                  ✅ Notes Generated for {subject} ({marks} Marks)
               </div>
               <div className="flex gap-2">
                  <button onClick={downloadPDF} className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors shadow-sm flex items-center gap-1">
                    📄 PDF
                  </button>
                  <button onClick={downloadWord} className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors shadow-sm flex items-center gap-1">
                    📝 Word
                  </button>
               </div>
            </div>

            {/* Visuals */}
            {visualUrls.length > 0 && (
                <section className={`rounded-2xl p-6 border overflow-hidden ${getCardClass()}`}>
                    <h3 className="text-lg font-bold mb-4 flex items-center gap-2 text-purple-600 dark:text-purple-400">
                      <span>🎨</span> Visual Learning
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {visualUrls.map((url, idx) => (
                             <div key={idx} className="flex flex-col items-center">
                                <img 
                                    src={url} 
                                    alt={`Visual Aid ${idx + 1}`} 
                                    className="w-full h-auto rounded-lg shadow-md border bg-white p-2 object-contain max-h-64"
                                />
                                <p className="mt-2 text-xs opacity-75 text-center italic">
                                  {idx === 0 ? "Conceptual Diagram" : "Real-World Illustration"}
                                </p>
                            </div>
                        ))}
                    </div>
                </section>
            )}

            {/* Text Notes Display */}
            <section className={`rounded-2xl p-8 border min-h-[500px] leading-relaxed ${getCardClass()}`}>
              <div 
                className="prose prose-sm md:prose-base max-w-none dark:prose-invert prose-headings:font-bold prose-h3:text-lg prose-h3:mt-6 prose-h3:mb-3 prose-p:my-2 prose-ul:list-disc prose-ul:pl-5 prose-li:my-1 prose-strong:text-blue-600 dark:prose-strong:text-blue-400"
                dangerouslySetInnerHTML={{ __html: notes }} 
              />
            </section>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="text-center py-6 opacity-60 text-sm">
        Generated using AI Study Notes Generator | Made by Loveleena 💖
      </footer>

      {/* Chatbot */}
      {notes && (
          <ChatInterface 
            subject={subject} 
            topic={topic} 
            theme={theme} 
            generatedNotes={notes || undefined}
            additionalContext={contextText}
          />
      )}

      <style>{`
        @keyframes fade-in-up {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-in-up {
            animation: fade-in-up 0.6s ease-out forwards;
        }
      `}</style>
    </div>
  );
};

export default App;