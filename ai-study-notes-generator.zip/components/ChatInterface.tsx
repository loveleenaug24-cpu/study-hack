import React, { useState, useRef, useEffect } from 'react';
import { ChatMessage } from '../types';
import { sendChatMessage } from '../services/geminiService';

interface ChatInterfaceProps {
  subject: string;
  topic: string;
  theme: string;
  generatedNotes?: string;
  additionalContext?: string;
}

export const ChatInterface: React.FC<ChatInterfaceProps> = ({ subject, topic, theme, generatedNotes, additionalContext }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      role: 'model',
      text: 'Hi there! I\'m your study assistant. Ask me anything about this topic!',
      timestamp: Date.now()
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isOpen]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      text: input,
      timestamp: Date.now()
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    try {
      // Convert internal message format to Gemini history format
      const historyForApi = messages.map(m => ({
        role: m.role,
        parts: [{ text: m.text }]
      }));

      const responseText = await sendChatMessage(
        historyForApi, 
        userMsg.text, 
        { 
          subject, 
          topic,
          generatedNotes,
          additionalContext
        }
      );

      const modelMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'model',
        text: responseText || "I'm having trouble connecting right now. Try again?",
        timestamp: Date.now()
      };
      setMessages(prev => [...prev, modelMsg]);
    } catch (error) {
      console.error("Chat error:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const getThemeClasses = () => {
    if (theme === 'dark') return 'bg-gray-800 text-white border-gray-700';
    if (theme === 'focus') return 'bg-[#fbf8f1] text-[#4a4036] border-[#dcb888]';
    return 'bg-white text-gray-900 border-gray-200';
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end">
      {isOpen && (
        <div className={`mb-4 w-80 sm:w-96 h-96 rounded-2xl shadow-2xl flex flex-col border overflow-hidden ${getThemeClasses()}`}>
          {/* Header */}
          <div className="p-4 border-b bg-opacity-5 bg-black flex justify-between items-center">
            <h3 className="font-bold text-sm">AI Tutor 🎓</h3>
            <button onClick={() => setIsOpen(false)} className="text-xs opacity-60 hover:opacity-100">Close</button>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`max-w-[85%] p-3 rounded-lg text-sm ${
                  msg.role === 'user'
                    ? 'ml-auto bg-blue-600 text-white rounded-tr-none'
                    : `mr-auto rounded-tl-none ${theme === 'dark' ? 'bg-gray-700' : 'bg-gray-100 text-gray-800'}`
                }`}
              >
                {msg.text}
              </div>
            ))}
            {isLoading && (
              <div className="mr-auto bg-gray-100 dark:bg-gray-700 p-3 rounded-lg rounded-tl-none text-xs animate-pulse">
                Thinking...
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <div className="p-3 border-t">
            <div className="flex gap-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Ask a doubt..."
                className={`flex-1 text-sm p-2 rounded border focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                    theme === 'dark' ? 'bg-gray-700 border-gray-600' : 'bg-white'
                }`}
              />
              <button
                onClick={handleSend}
                disabled={isLoading}
                className="bg-blue-600 text-white p-2 rounded hover:bg-blue-700 disabled:opacity-50"
              >
                ➤
              </button>
            </div>
          </div>
        </div>
      )}

      <button
        onClick={() => setIsOpen(!isOpen)}
        className="h-14 w-14 rounded-full bg-blue-600 text-white shadow-lg flex items-center justify-center hover:bg-blue-700 transition-all hover:scale-110"
      >
        {isOpen ? '✕' : '💬'}
      </button>
    </div>
  );
};