import React from 'react';
import { AppTheme } from '../types';

interface ThemeToggleProps {
  currentTheme: AppTheme;
  onThemeChange: (theme: AppTheme) => void;
}

export const ThemeToggle: React.FC<ThemeToggleProps> = ({ currentTheme, onThemeChange }) => {
  return (
    <div className="flex gap-2 bg-opacity-20 bg-gray-500 p-1 rounded-full backdrop-blur-sm">
      <button
        onClick={() => onThemeChange(AppTheme.LIGHT)}
        className={`px-3 py-1 rounded-full text-xs font-medium transition-all ${
          currentTheme === AppTheme.LIGHT 
            ? 'bg-white text-gray-900 shadow-sm' 
            : 'text-gray-500 dark:text-gray-300 hover:bg-white/10'
        }`}
      >
        Light
      </button>
      <button
        onClick={() => onThemeChange(AppTheme.DARK)}
        className={`px-3 py-1 rounded-full text-xs font-medium transition-all ${
          currentTheme === AppTheme.DARK 
            ? 'bg-gray-800 text-white shadow-sm' 
            : 'text-gray-500 dark:text-gray-300 hover:bg-white/10'
        }`}
      >
        Dark
      </button>
      <button
        onClick={() => onThemeChange(AppTheme.FOCUS)}
        className={`px-3 py-1 rounded-full text-xs font-medium transition-all ${
          currentTheme === AppTheme.FOCUS 
            ? 'bg-[#dcb888] text-[#4a4036] shadow-sm' 
            : 'text-gray-500 dark:text-gray-300 hover:bg-white/10'
        }`}
      >
        Focus
      </button>
    </div>
  );
};
