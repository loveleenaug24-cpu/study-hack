export enum AppTheme {
  LIGHT = 'light',
  DARK = 'dark',
  FOCUS = 'focus'
}

export interface NoteRequest {
  subject: string;
  topic: string;
  marks: string; // "2", "5", "10", "15"
  contextText: string;
  contextLink: string;
  fileData?: {
    data: string; // Base64
    mimeType: string;
  };
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: number;
}

export interface GeneratedContent {
  notes: string;
  visuals: string[]; // Base64 image data
  motivation: string;
}