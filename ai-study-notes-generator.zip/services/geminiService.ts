import { GoogleGenAI } from "@google/genai";
import { NoteRequest } from "../types";

// Initialize Gemini Client
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Returns the specific structure instructions based on marks.
 */
const getStructureForMarks = (marks: string): string => {
  switch (marks) {
    case "2":
      return `
       - <h3>DEFINITION</h3>
       - <h3>COMMON DOUBTS & CLARIFICATIONS</h3>
      `;
    case "5":
      return `
       - <h3>DEFINITION</h3>
       - <h3>KEY POINTS</h3> (Bullet points)
       - <h3>ONE LINE EXAMPLE</h3>
       - <h3>COMMON DOUBTS & CLARIFICATIONS</h3>
      `;
    case "10":
      return `
       - <h3>INTRODUCTION</h3>
       - <h3>MAIN EXPLANATION</h3> (Detailed points)
       - <h3>EXAMPLE OR DIAGRAM DESCRIPTION</h3>
       - <h3>ADVANTAGES OR IMPORTANCE</h3>
       - <h3>CONCLUSION</h3>
       - <h3>COMMON DOUBTS & CLARIFICATIONS</h3>
      `;
    case "15":
      return `
       - <h3>INTRODUCTION</h3>
       - <h3>DETAILED EXPLANATION</h3>
       - <h3>ADVANTAGES</h3>
       - <h3>DISADVANTAGES OR LIMITATIONS</h3>
       - <h3>REAL-WORLD EXAMPLE</h3>
       - <h3>CONCLUSION</h3>
       - <h3>COMMON DOUBTS & CLARIFICATIONS</h3>
      `;
    default:
      return `
       - <h3>INTRODUCTION</h3>
       - <h3>KEY CONCEPTS</h3>
       - <h3>DETAILED EXPLANATION</h3>
       - <h3>SUMMARY</h3>
       - <h3>COMMON DOUBTS & CLARIFICATIONS</h3>
      `;
  }
};

/**
 * Generates the structured study notes based on user input.
 */
export const generateStudyNotes = async (request: NoteRequest): Promise<string> => {
  const { subject, topic, marks, contextText, contextLink, fileData } = request;

  const structureInstructions = getStructureForMarks(marks);

  const prompt = `
    You are an expert AI tutor helping a student create clear, exam-friendly study notes.
    
    SUBJECT: ${subject}
    TOPIC: ${topic}
    MARKS WEIGHTAGE: ${marks} Marks
    
    ADDITIONAL CONTEXT/MATERIAL:
    ${contextText}
    ${contextLink ? `Link: ${contextLink}` : ''}

    INSTRUCTIONS:
    1. Create clean, well-structured study notes tailored to the marks weightage.
    2. OUTPUT FORMAT: HTML.
       - Use <h3> for main headings (e.g., INTRODUCTION, KEY CONCEPTS).
       - Use <b> for subheadings or emphasis (Do not use **).
       - Use <ul> and <li> for bullet points.
       - Use <br> for line breaks.
       - Do NOT use Markdown symbols (#, ##, *, -).
       - Do NOT include <html>, <head>, or <body> tags. Just the content.
    
    3. LANGUAGE: Simple, student-friendly, and engaging.
    
    4. REQUIRED STRUCTURE (Strictly follow this based on ${marks} marks):
    ${structureInstructions}
    
    5. MOTIVATION:
       - End the notes with a short, encouraging motivational quote or tip for the student.

    Make the notes look professional, accurate, and supportive.
  `;

  const parts: any[] = [{ text: prompt }];

  // If a file (PDF/Text) was uploaded, add it to the request
  if (fileData) {
    parts.push({
      inlineData: {
        mimeType: fileData.mimeType,
        data: fileData.data
      }
    });
  }

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: { parts },
    });
    return response.text || "Failed to generate notes.";
  } catch (error) {
    console.error("Error generating notes:", error);
    throw error;
  }
};

/**
 * Generates multiple visuals (Diagram + Illustration)
 */
export const generateVisuals = async (subject: string, topic: string): Promise<string[]> => {
  const visuals: string[] = [];

  // Prompt 1: Educational Diagram
  const promptDiagram = `Create a clean, schematic educational diagram or flowchart explaining "${topic}" in the context of "${subject}". White background, clear labels, textbook style.`;
  
  // Prompt 2: Real World Illustration
  const promptIllustration = `Create a realistic illustration or real-world application image related to "${topic}" in "${subject}". High quality, educational, engaging.`;

  try {
    const [response1, response2] = await Promise.all([
      ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: { parts: [{ text: promptDiagram }] },
      }),
      ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: { parts: [{ text: promptIllustration }] },
      })
    ]);

    // Extract image 1
    const parts1 = response1.candidates?.[0]?.content?.parts || [];
    for (const part of parts1) {
      if (part.inlineData) visuals.push(`data:${part.inlineData.mimeType};base64,${part.inlineData.data}`);
    }

    // Extract image 2
    const parts2 = response2.candidates?.[0]?.content?.parts || [];
    for (const part of parts2) {
      if (part.inlineData) visuals.push(`data:${part.inlineData.mimeType};base64,${part.inlineData.data}`);
    }

  } catch (error) {
    console.warn("Visual generation failed:", error);
  }

  return visuals;
};

/**
 * Chatbot interaction function.
 */
export const sendChatMessage = async (
  history: { role: string; parts: { text: string }[] }[],
  message: string,
  contextData?: { 
    subject: string; 
    topic: string; 
    generatedNotes?: string;
    additionalContext?: string;
  }
) => {
  // Strip HTML tags for the prompt to save tokens and avoid confusion
  const cleanNotes = contextData?.generatedNotes 
    ? contextData.generatedNotes.replace(/<[^>]*>/g, '') 
    : '';

  const systemPrompt = `You are a friendly, supportive AI tutor. 
  
  CONTEXT:
  Subject: "${contextData?.subject}"
  Topic: "${contextData?.topic}"
  
  ${cleanNotes ? `THE NOTES YOU JUST GENERATED FOR THE STUDENT:\n${cleanNotes}\n` : ''}
  ${contextData?.additionalContext ? `STUDENT PROVIDED MATERIALS:\n${contextData.additionalContext}\n` : ''}

  Your capabilities:
  - Explain parts of the notes in simpler words if asked.
  - Answer specific academic doubts related to the topic.
  - Be encouraging and clear.
  - Use plain text for your responses (no complex markdown).
  
  If the student asks about marks or exams, give advice based on standard academic practices.`;

  const chat = ai.chats.create({
    model: 'gemini-3-flash-preview',
    history: [
      {
        role: 'user',
        parts: [{ text: systemPrompt }]
      },
      {
        role: 'model',
        parts: [{ text: "Hello! I am your AI study companion. I'm here to help you understand this topic better. What do you need help with?" }]
      },
      ...history
    ],
  });

  const response = await chat.sendMessage({ message });
  return response.text;
};